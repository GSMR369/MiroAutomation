package CucumberStepDefinitions;

import PageObjects.HomePage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GenericFunctions {

    private WebDriver driver;
    private HomePage homePage;
    private Waits waits;

    public GenericFunctions(WebDriver driver) {
        this.driver = driver;
    }

    public static void killExistingChromeDriver() {
        try {
            Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
        } catch (IOException e) {
            System.out.println("Error with chrome driver killing process");
        }
    }

    public void highlightElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        //js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
        js.executeScript("arguments[0].setAttribute('style', 'border: 2px solid red;');", element);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
        js.executeScript("arguments[0].setAttribute('style','border: solid 2px none');", element);
    }

    public static String createScreenshotFileName() {
        final StringBuffer sb = new StringBuffer();
        final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HHmmss");
        final String timestamp = dateFormat.format(new Date());
        sb.append(timestamp).append(".png");
        return sb.toString();
    }

    public boolean elementDisplayedConditionCheck(WebElement elementName) {
        boolean condition;
        try {
            condition = elementName.isDisplayed();
        } catch (Exception e) {
            condition = false;
        }
        return condition;
    }

    public void tryCatchElement(WebElement element) {
        try {
            element.click();
        } catch (Exception e) {
        }
    }
}