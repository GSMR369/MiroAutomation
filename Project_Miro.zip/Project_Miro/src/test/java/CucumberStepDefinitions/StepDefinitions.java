package CucumberStepDefinitions;

import PageObjects.HomePage;
import com.vimalselvam.cucumber.listener.Reporter;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.io.IOException;


public class StepDefinitions {

    public WebDriver driver;
    private HomePage homePage;
    private Waits waits;
    private ChromeOptions chromeOptions;
    public GenericFunctions genericFunctions;

    private static String getURL;

    @After
    public void tearDown(Scenario scenario) throws IOException, Throwable {
        homePage = new HomePage(driver);
        waits = new Waits(driver);
        genericFunctions = new GenericFunctions(driver);

        //Extent Reports: paths
        String targetPath = new File("..\\Project_M3P_Regressie\\output\\screenshot_" + genericFunctions.createScreenshotFileName()).getCanonicalPath();
        System.out.println("targetPath = " + targetPath);

        String configFileName = new File("..\\Project_M3P_Regressie\\extentreports-java-2.41.2\\extent-config.xml").getCanonicalPath();
        System.out.println("configFileName = " + configFileName);

        //If scenario fails, add a screenshot to the report
        if (scenario.isFailed()) {
            try {
                scenario.write("Current Page URL is " + driver.getCurrentUrl());
                byte[] screenshot = ((TakesScreenshot) driver)
                        .getScreenshotAs(OutputType.BYTES);
                scenario.embed(screenshot, "image/png"); //stick it in the report
                try {
                    File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                    FileUtils.copyFile(screenshotFile, new File(targetPath));
                    Reporter.addScreenCaptureFromPath((targetPath));
                } catch (IOException e) {
                    System.out.println("Error Error Error");
                }
            } catch (WebDriverException somePlatformsDontSupportScreenshots) {
                System.err.println(somePlatformsDontSupportScreenshots.getMessage());
            }
        }

        driver.quit();
        System.out.println("-----------In this step user logout from application----------");
        GenericFunctions.killExistingChromeDriver();

        Reporter.loadXMLConfig(configFileName);
    }


    @Given("^As a \"([^\"]*)\" I login into service and create a board with name \"([^\"]*)\"$")
    public void asAILoginIntoServiceAndCreateABoardWithName(String user1, String nameOfBaord) throws Throwable {
        String exePathDefault = new File("C:\\CodeBackup\\sanctions_test_automation\\BrowserDrivers\\chromedriver.exe").getAbsolutePath();
        System.setProperty("webdriver.chrome.driver", exePathDefault);
        //driver = new ChromeDriver();
        // start the proxy
        BrowserMobProxy proxy = new BrowserMobProxyServer();
        proxy.start(0);
        Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
        ChromeOptions options = new ChromeOptions();
        Proxy proxytest = ClientUtil.createSeleniumProxy(proxy);
        options.setProxy(proxytest);

        try {
            driver = new ChromeDriver();
        } catch (WebDriverException e) {
            System.out.println("Trying to start Chrome again");
            driver = new ChromeDriver();
        }

        driver.manage().window().maximize();
        driver.get("https://miro.com/login/");
        homePage = new HomePage(driver);
        waits = new Waits(driver);
        genericFunctions = new GenericFunctions(driver);

        boolean helper;
        waits.commonVisibilityOfWaitId("email", "Email");
        homePage.workEmailtextBox.sendKeys(user1);
        homePage.passwordtextBox.sendKeys("Work4sun@");
        homePage.signInbutton.click();
        waits.commonVisibilityOfWaitXpath("//*[@id='router-container-wrapper']//div[contains(@class,'dashboard-templates__brick dashboard-templates__new-brick')]", "New Board");
        System.out.println("Log in successful");
        homePage.newBoardAdd.click();
        waits.commonVisibilityOfWaitXpath("//button[contains(text(),'Create a shared board')]", "Create A Shared Board");
        homePage.createAShardBoardbutton.click();
        Thread.sleep(10000);
        waits.commonVisibilityOfWaitXpath("*//div[contains(@class,'rtb-modal-container__close rtb-modal-close')]", "Close Icon");
        homePage.closeicon.click();
        waits.commonVisibilityOfWaitXpath("//div[contains(@class,'board-top-left-panel__title board-top-left-panel__title--editable')]", "BoardNameTitle");
        waits.commonClickableOfWaitXpath("//div[contains(@class,'board-top-left-panel__title board-top-left-panel__title--editable')]", "BoardNameTitle");
        for (int i = 0; i < 10; i++) {
            helper = genericFunctions.elementDisplayedConditionCheck(homePage.boardNameTitlefield);
            if (helper) {
                homePage.boardNameTitlefield.click();
                break;
            }
        }
        waits.commonVisibilityOfWaitXpath("//div[contains(@class,'md-content__info')]//input[1]", "NameBoardTitile");
        waits.commonClickableOfWaitXpath("//div[contains(@class,'md-content__info')]//input[1]", "NameBoardTitile");
        homePage.nameBoardTitiletextBox.clear();
        homePage.nameBoardTitiletextBox.sendKeys(nameOfBaord);
        homePage.nameBoardTitiletextBox.sendKeys(Keys.ENTER);
        getURL = driver.getCurrentUrl();
        System.out.println("Newly Created Board URL is: " + getURL);
    }

    @When("^As a \"([^\"]*)\" I open \"([^\"]*)\" and create there stciker\\(sticker widget\\), by using left toolbar$")
    public void asAIOpenAndCreateThereStcikerStickerWidgetByUsingLeftToolbar(String user, String boardName) throws Throwable {
        homePage = new HomePage(driver);
        waits = new Waits(driver);
        genericFunctions = new GenericFunctions(driver);

        boolean helper;
        Actions performAction = new Actions(driver);
        waits.commonClickableOfWaitXpath("//*[@id='canvasContainer']//div[contains(@class,'toolbar__item toolbar__item--customized AT__toolbar--STICKERS toolbar__item--stickers')]", "Sticky Notes");
        for (int i = 0; i <= 5; i++) {
            performAction.moveToElement(homePage.stickyNotesfield).click().build().perform();
            helper = genericFunctions.elementDisplayedConditionCheck(homePage.stickyNotesColorfield);
            if (helper)
                break;
        }
        waits.commonClickableOfWaitXpath("//*[@id='canvasContainer']//div[contains(@class,'toolbar__panel toolbar__panel--stickers use-ng-animate')]/div[5]", "Sticky Notes Color");
        performAction.moveToElement(homePage.stickyNotesColorfield).click().build().perform();        //homePage.stickyNotesColorfield.click();
        performAction.moveToElement(homePage.stickyNotesColorfield, 300, 300).click().build().perform();
        for (int i = 0; i <= 10; i++) {
            helper = genericFunctions.elementDisplayedConditionCheck(homePage.stickyTextAreafield);
            if (helper) {
                homePage.stickyTextAreafield.click();
                performAction.moveToElement(homePage.stickyTextAreafield).click().sendKeys("Miro").build().perform();
                break;
            }

        }
    }

    @And("^As a \"([^\"]*)\" I Invite \"([^\"]*)\" to \"([^\"]*)\" by using \"([^\"]*)\" button on the top right corner\"$")
    public void asAIInviteToByUsingButtonOnTheTopRightCorner(String user1, String user2, String boardName, String actionNeeded) throws Throwable {
        homePage = new HomePage(driver);
        waits = new Waits(driver);
        genericFunctions = new GenericFunctions(driver);

        Actions performAction = new Actions(driver);
        waits.commonClickableOfWaitXpath("//div[@class='board-top-right-panel board-panel--transparent backdrop-blur board-panel--hidden-top']//*[@id='share-board-button']", "Share Button");
        if (actionNeeded.equals("share")) {
            homePage.shareButton.click();
            waits.commonVisibilityOfWaitXpath("//div[contains(@class,emails-editor-react)]//span[contains(@class,'email-input email-input--badge-like email-input--with-placeholder')]", "To Email");
            performAction.moveToElement(homePage.toListEmailtextBox).click().build().perform();
            performAction.moveToElement(homePage.toListEmailtextBox).sendKeys(user2).build().perform();
            waits.commonClickableOfWaitXpath("//div[contains(@class,'share-content__buttons-panel')]//button[contains(@data-auto-test-id,'shareMdButtonSend')]", "Send invitations");
            homePage.canEditlink.click();
            homePage.sendInvitationsButton.click();
            waits.commonVisibilityOfWaitXpath("//button[contains(@class,'rtb-btn rtb-btn--primary rtb-btn--small') and text()='Done']", "Done Button");
            homePage.doneButton.click();
        }
        //driver.close();
        waits.commonClickableOfWaitXpath("//div[contains(@class,'svg-button board-top-left-panel__dashboard')][1]", "Miro Menu");
        homePage.miroMenufield.click();
        waits.commonClickableOfWaitXpath("//*[@id='router-container-wrapper']//div[contains(@class,'dashboard-header--top')]//img", "Profile Menu");
        homePage.profileMenufield.click();
        waits.commonClickableOfWaitXpath("//*[@id='router-container-wrapper']//div[contains(@class,'user-profile__buttons')]//span[contains(text(),'Log out')]", "Log Out");
        driver.get("http://miro.com/login");
    }

    @And("^As a \"([^\"]*)\" I login into service and open \"([^\"]*)\"$")
    public void asAILoginIntoServiceAndOpen(String user2, String boardName) throws Throwable {
        waits = new Waits(driver);
        homePage = new HomePage(driver);
        System.out.println("Current URL Is: " + getURL);
        driver.get("http://miro.com/login");
        waits.waitForPageToLoadAfterSomeAction(40);
        waits.commonVisibilityOfWaitId("email", "Email");
        homePage.workEmailtextBox.clear();
        homePage.workEmailtextBox.sendKeys(user2);
        homePage.passwordtextBox.sendKeys("Work4tharaka@");
        homePage.signInbutton.click();
        waits.waitForPageToLoadAfterSomeAction(40);
        System.out.println("User logged into system");
    }

    @Then("^As a \"([^\"]*)\" I should see created sticker on \"([^\"]*)\"$")
    public void asAIShouldSeeCreatedStickerOn(String arg0, String arg1) throws Throwable {
        waits = new Waits(driver);
        homePage = new HomePage(driver);

        boolean helper1, helper2, helper3;
        Actions performAction = new Actions(driver);
        try {
            Alert alert = driver.switchTo().alert();
            alert.accept();
        } catch (Exception e) {
        }
        for (int i = 0; i <= 10; i++) {
            Thread.sleep(500);
            helper1 = genericFunctions.elementDisplayedConditionCheck(homePage.createBoardimage);
            if (helper1) {
                if (!genericFunctions.elementDisplayedConditionCheck(homePage.stickyNotesfield))
                    performAction.moveToElement(homePage.createBoardimage).doubleClick(homePage.createBoardimage).build().perform();
                helper2 = genericFunctions.elementDisplayedConditionCheck(homePage.stickyNotesfield);
                if (helper2)
                    break;
            }
        }
        System.out.println("User successfully opened the shared board");
        waits.commonClickableOfWaitXpath("//*[@id='canvasContainer']//div[contains(@class,'toolbar__item toolbar__item--customized AT__toolbar--STICKERS toolbar__item--stickers')]", "Sticky Notes");
        for (int i = 0; i <= 5; i++) {
            performAction.moveToElement(homePage.stickyNotesfield).click().build().perform();
            helper3 = genericFunctions.elementDisplayedConditionCheck(homePage.stickyNotesColorfield);
            if (helper3)
                break;
        }
        waits.commonClickableOfWaitXpath("//*[@id='canvasContainer']//div[contains(@class,'toolbar__panel toolbar__panel--stickers use-ng-animate')]/div[5]", "Sticky Notes Color");
        performAction.moveToElement(homePage.stickyNotesColorfield).click().build().perform();
        performAction.moveToElement(homePage.stickyNotesColorfield, 500, 500).click().build().perform();
        waits.commonVisibilityOfWaitXpath("//*[@id='widgetsOverlay']//div[contains(@class,'ql-editor')]/p", "Sticky Notes Content");
        String notesActualValue = homePage.stickyNotesTextContentfield.getText();
        Assert.assertEquals("Miro", notesActualValue);
    }
}