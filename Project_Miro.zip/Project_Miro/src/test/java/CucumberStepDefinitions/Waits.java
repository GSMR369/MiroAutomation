package CucumberStepDefinitions;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class Waits {

    private WebDriver driver;

    public Waits(WebDriver driver) {
        this.driver = driver;
    }

    public void commonClickableOfWaitXpath(String element, String elementName) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element)));
        } catch (JavascriptException | TimeoutException | NoSuchElementException e) {
            System.out.println("Unable to find element: " + elementName);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element)));
        }
    }


    public void commonVisibilityOfWaitId(String element, String elementName) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(element)));
        } catch (JavascriptException | NoSuchElementException e) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(element)));
            System.out.println("Unable to the find element: " + elementName);
        }
    }

    public void commonVisibilityOfWaitXpath(String element, String elementName) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
        } catch (JavascriptException | NoSuchElementException e) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
            System.out.println("Unable to the find element: " + elementName);
        }
    }

    public void waitForPageToLoadAfterSomeAction(Integer waitTimeInSeconds) {
        driver.manage().timeouts().pageLoadTimeout(waitTimeInSeconds, TimeUnit.SECONDS);
    }
}
