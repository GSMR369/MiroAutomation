package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    public HomePage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[@id='header-login-btn']")
    public WebElement miroLoginLink;

    @FindBy(id = "email")
    public WebElement workEmailtextBox;

    @FindBy(id = "password")
    public WebElement passwordtextBox;

    @FindBy(xpath = "*//button[contains(text(),'Sign in')]")
    public WebElement signInbutton;

    @FindBy(xpath = "//*[@id='router-container-wrapper']//div[contains(@class,'dashboard-templates__brick dashboard-templates__new-brick')]")
    public WebElement newBoardAdd;

    @FindBy(xpath = "//button[contains(text(),'Create a shared board')]")
    public WebElement createAShardBoardbutton;

    @FindBy(xpath = "*//div[contains(@class,'rtb-modal-container__close rtb-modal-close')]")
    public WebElement closeicon;

    @FindBy(xpath = "//div[contains(@class,'board-top-left-panel__title board-top-left-panel__title--editable')]")
    public WebElement boardNameTitlefield;

    @FindBy(xpath = "//div[contains(@class,'md-content__info')]//input[1]")
    public WebElement nameBoardTitiletextBox;

    @FindBy(xpath = "//div[@class='board-top-right-panel board-panel--transparent backdrop-blur board-panel--hidden-top']//*[@id='share-board-button']")
    public WebElement shareButton;

    @FindBy(xpath = "//*[@id='canvasContainer']//div[contains(@class,'toolbar__item toolbar__item--customized AT__toolbar--STICKERS toolbar__item--stickers')]")
    public WebElement stickyNotesfield;

    @FindBy(xpath = "//div[contains(@class,'toolbar__panel toolbar__panel--stickers use-ng-animate')]/div[5]")
    public WebElement stickyNotesColorfield;

    @FindBy(xpath = "//*[@id='widgetsOverlay']//div[contains(@class,'ql-editor ql-blank')]/p")
    public WebElement stickyTextAreafield;

    @FindBy(xpath = "//div[contains(@class,emails-editor-react)]//span[contains(@class,'email-input email-input--badge-like email-input--with-placeholder')]")
    public WebElement toListEmailtextBox;

    @FindBy(xpath = "//div[contains(@class,'share-content__buttons-panel')]//button[contains(@data-auto-test-id,'shareMdButtonSend')]")
    public WebElement sendInvitationsButton;

    @FindBy(xpath = "//button[contains(@class,'rtb-btn rtb-btn--primary rtb-btn--small') and text()='Done']")
    public WebElement doneButton;

    @FindBy(xpath = "//button[contains(@class,'rtb-select__button')]//span[contains(@class,'rtb-select__button-text') and text()='Can edit']")
    public WebElement canEditlink;

    @FindBy(xpath = "//div[contains(@class,'svg-button board-top-left-panel__dashboard')][1]")
    public WebElement miroMenufield;

    @FindBy(xpath = "//*[@id='router-container-wrapper']//div[contains(@class,'dashboard-header--top')]//img")
    public WebElement profileMenufield;

    @FindBy(xpath = "//*[@id='router-container-wrapper']//div[contains(@class,'user-profile__buttons')]//span[contains(text(),'Log out')]")
    public WebElement logOutfield;

    @FindBy(xpath = "*//div[contains(@class,'progressive-image')]/img")
    public WebElement createBoardimage;

    @FindBy(xpath = "//div[contains(@class,'canvas-fixed-container')]/div")
    public WebElement containerReferencefield;

    @FindBy(xpath = "//*[@id='widgetsOverlay']//div[contains(@class,'ql-editor')]/p")
    public WebElement stickyNotesTextContentfield;
}